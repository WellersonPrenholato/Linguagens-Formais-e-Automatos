/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package analisador_lex;

/**
 *
 * @author thiag
 */
public interface tokens_comands {
    enum Token {NEWLINE, EOF, FOR, IF, WHILE, ESPACO, PP, PT, AP, FP, VARIAVEL, NUMERO, CARACTERE, OPLOG, OPLOGBIN, OPARITBIN, OPRELBIN, OPLOGUN, ATRIBUICAO, OPUNBIN, NUM, SEPARADOR}
    
    
    char    EOF = 0,
            ESPACO = ' ',
            PP = ':',
            AP = '(',
            FP = ')',
            ATRIBUICAO = '=',
            PT = '.';
    
    String  WHILE = "while",
            FOR = "for",
            IF = "if",
            VARIAVEL = "ABCDEFGHIJKLMNOPQRSTUVXWYZabcdefghijklmnopqrstuvxwyz_",
            NUM = "0123456789",
            OPLOGBIN = "|&&||",
            OPARITBIN = "*//**/%",
            OPRELBIN = "><>=<=is==", 
            OPUNBIN = "+-",
            OPLOGUN = "!not",
            OPLOG =  OPRELBIN + OPLOGBIN + OPARITBIN + OPUNBIN  + OPLOGUN,
            NUMERO = OPUNBIN + VARIAVEL,
            NEWLINE = "\n",
            SEPARADOR = "\t\r",
            ALFABETO = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+-_*/%&|=!&|><()':" + EOF;
            
    String  NOME_DEFAULT_ARQUIVO_ENTRADA = "entrada.txt";
}
