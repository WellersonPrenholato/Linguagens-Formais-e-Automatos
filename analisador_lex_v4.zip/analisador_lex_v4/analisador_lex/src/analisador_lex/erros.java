package analisador_lex;
public class erros extends RuntimeException 
{
    private char simboloEncontrado;
    private String simbolosEsperados;
    private int linha;
    
    

    public erros( char simboloEncontrado, String simbolosEsperados, int linha )
    {
        this.simboloEncontrado = simboloEncontrado;
        this.simbolosEsperados = simbolosEsperados;
        this.linha = linha;
    }
    
  
    public String toString()
    {
        if(this.simbolosEsperados != null){
        return "Simbolo encontrado: " + (char)this.simboloEncontrado + 
                "\n era(m) esperado(s):" + this.simbolosEsperados + " na linha : " + this.linha ;
                
        }
        return "";
    }
    
}
