package analisador_lex;

public class estados extends Analisador_lex 
{
    
    /**
    * Contrutor da classe 
    * @author 
    * @param nome diretorio/nome do arquivo a ser analisado
    */
    public estados( String nome )
    {
        super(nome);
    }
    
    
    /**
    * Estado inicial da maquina
    * @author 
    */
        public void q0(){


        if( proxCaractereIs(SEPARADOR))
        {
            this.tokenReconhecido = Token.SEPARADOR;
            if ( this.proxCaractere == '\n' ) this.linha++;
            leProxCaractere();
            q0();
        }

        else if( this.proxCaractere == EOF )
        {
            this.tokenReconhecido = Token.EOF;
            //leProxCaractere();
            fim();
        }

        else if(this.proxCaractere == '(' )
        {
            leProxCaractere();
            q1();
        }

        else if( this.proxCaractere == ')' )
        {
            leProxCaractere();
            q2();
        }

        else if(this.proxCaractere == 'w'){
            leProxCaractere();
            q20();
        }

        else if(this.proxCaractere == 'i'){
            leProxCaractere();
            q29();
        }   

        else if(this.proxCaractere == 'f'){
            leProxCaractere();
            q26();
        }

        else if(this.proxCaractere == ':'){
            leProxCaractere();
            q35();
        }

        else if(this.proxCaractere == '%'){
            leProxCaractere();
            q13();
        }

        else if(this.proxCaractere == ' '){
            leProxCaractere();
            q3();
        }

        else if(this.proxCaractere == '.'){
            leProxCaractere();
            q19();
        }

        else if(this.proxCaractere == '='){
            leProxCaractere();
            q16();
        }

        else if(this.proxCaractere == '-'){
            leProxCaractere();
            q15();
        }

        else if(this.proxCaractere == '+'){
            leProxCaractere();
            q15();
        }
        else if(this.proxCaractere == '*'){
            leProxCaractere();
            q14();
        }

        else if(this.proxCaractere == '|'){
            leProxCaractere();
            q11();
        }

        else if(this.proxCaractere == '/'){
            leProxCaractere();
            q12();
        }

        else if(this.proxCaractere == '&'){
            leProxCaractere();
            q8();
        }

        else if(this.proxCaractere == '!'){
            leProxCaractere();
            q7();
        }

        else if(this.proxCaractere == '<'){
            leProxCaractere();
            q6();
        }

        else if(this.proxCaractere == '>'){
            leProxCaractere();
            q4();
        }
        else if(proxCaractereIs(NEWLINE)){
            q10();
        }
        else if(this.proxCaractereIs (NUM)){
            leProxCaractere();
            q17();
        }
        else if(this.proxCaractereIs(VARIAVEL) && !this.proxCaractereIs(NUM)  && this.proxCaractere != 'w' && this.proxCaractere != 'i' && this.proxCaractere != 'f' && this.proxCaractere != 'n'){
            leProxCaractere();
            q25();
        }
        else if(this.proxCaractere == 'n'){
            leProxCaractere();
            q32();
        }else {
            System.out.println("Entrada Ivalida");
            throw(new erros(this.proxCaractere,ALFABETO, this.linha));
        }
        }





    public void q1(){
        this.tokenReconhecido = Token.AP;

    }

    public void q2(){
        this.tokenReconhecido = Token.FP;
    }

    public void q3(){
        this.tokenReconhecido = Token.ESPACO;

    }

    public void q4(){
        this.tokenReconhecido = Token.OPRELBIN;
        leProxCaractere();
        if(this.proxCaractere == '='){
            leProxCaractere();
            q5();
        }
    }

    public void q5(){
        this.tokenReconhecido = Token.OPRELBIN;
    }

    public void q6(){
        this.tokenReconhecido = Token.OPRELBIN;
        if(this.proxCaractere == '='){
            leProxCaractere();
            q5();
        }
    }

    public void q7(){
        this.tokenReconhecido = Token.OPLOGUN;
        if(this.proxCaractere == '='){
            leProxCaractere();
            q5();
        }
    }

    public void q8(){
        this.tokenReconhecido = Token.OPLOGUN;
        if(this.proxCaractere == '&'){
            leProxCaractere();
            q9();
        }
    }

    public void q9(){
        this.tokenReconhecido = Token.OPLOGBIN;
    }

    public void q10(){
        this.tokenReconhecido = Token.NEWLINE;
         if ( this.proxCaractere == '\n' ) this.linha++;
            leProxCaractere();
    }

    public void q11(){
        if(this.proxCaractere == '/'){
            leProxCaractere();
            q13();
        }else{
            System.out.println("Entrada nÃ£o reconhecida");
            throw(new erros(this.proxCaractere,"'",this.linha));
        }        
    }
    
    public void q12(){
        this.tokenReconhecido = Token.OPARITBIN;
        if(this.proxCaractere == '/'){
            leProxCaractere();
            q13();
        }
    }
    public void q13(){
        this.tokenReconhecido = Token.OPARITBIN;
    }
    public void q14(){
        this.tokenReconhecido = Token.OPARITBIN;
        if(this.proxCaractere == '*'){
            leProxCaractere();
            q13();
        }
    }
    public void q15(){
        this.tokenReconhecido = Token.OPUNBIN;
    }
    public void q16(){
        this.tokenReconhecido = Token.ATRIBUICAO;
        leProxCaractere();
        if(this.proxCaractere == '='){
            
            q5();
        }
    }
    public void q17(){
        this.tokenReconhecido = Token.NUM;
        if(this.proxCaractere == '.'){
            leProxCaractere();
            q18();
        }
    }
    public void q18(){
        this.tokenReconhecido = Token.NUM;
        if(this.proxCaractere == '.'){
            leProxCaractere();
            q18();
        }
    }
    public void q19(){
        this.tokenReconhecido = Token.PT;
        if(proxCaractereIs(NUM)){
            leProxCaractere();
            q18();
        }else{
            System.out.println("Entrada nÃ£o reconhecida");
            throw(new erros(this.proxCaractere,"'",this.linha));
        } 
    }
    public void q20(){
        this.tokenReconhecido = Token.VARIAVEL;
        if(this.proxCaractere == 'h'){
            leProxCaractere();
            q21();
        }else if(proxCaractereIs(VARIAVEL) && this.proxCaractere != 'h'){
            leProxCaractere();
            q25();
        }
    }
    public void q21(){
        this.tokenReconhecido = Token.VARIAVEL;
        if(this.proxCaractere == 'i'){
            leProxCaractere();
            q22();
        }else if(proxCaractereIs(VARIAVEL) && this.proxCaractere != 'i'){
            leProxCaractere();
            q25();
        }
    }

    public void q22(){
        this.tokenReconhecido = Token.VARIAVEL;
        if(this.proxCaractere == 'l'){
            leProxCaractere();
            q23();
        }else if(proxCaractereIs(VARIAVEL) && this.proxCaractere != 'l'){
            leProxCaractere();
            q25();
        }
    }

    public void q23(){
        this.tokenReconhecido = Token.VARIAVEL;
        if(this.proxCaractere =='e'){
            leProxCaractere();
            q24();
        }else if(proxCaractereIs(VARIAVEL) && this.proxCaractere != 'e'){
            leProxCaractere();
            q25();
        }
    }
    public void q24(){
        this.tokenReconhecido = Token.WHILE;
        if(proxCaractereIs(VARIAVEL)){
            leProxCaractere();
            q25();
        }
    }
    public void q25(){
        this.tokenReconhecido = Token.VARIAVEL;
        if(this.proxCaractereIs(VARIAVEL) || this.proxCaractereIs(NUM) ){
            leProxCaractere();
            q25();
        }
    }
    public void q26(){
        this.tokenReconhecido = Token.VARIAVEL;
        if(proxCaractereIs(VARIAVEL) && this.proxCaractere != 'o'){
            leProxCaractere();
            q27();
        }else if(proxCaractereIs(VARIAVEL) && this.proxCaractere != 'o'){
            leProxCaractere();
            q25();
        }
    }
    public void q27(){
        this.tokenReconhecido = Token.VARIAVEL;
        if(this.proxCaractere == 'r'){
            leProxCaractere();
            q28();
        }else if(proxCaractereIs(VARIAVEL) && this.proxCaractere != 'r'){
            leProxCaractere();
            q25();
        }
    }
    public void q28(){
        this.tokenReconhecido = Token.FOR;
        if(proxCaractereIs(VARIAVEL)){
            leProxCaractere();
            q25();
        }
    }
    public void q29(){
        this.tokenReconhecido = Token.VARIAVEL;
        if(this.proxCaractere == 'f'){
            leProxCaractere();
            q30();
        }else if(this.proxCaractere == 's'){
            leProxCaractere();
            q31();
        }else if(proxCaractereIs(VARIAVEL) && this.proxCaractere != 'f' && this.proxCaractere != 's'){
            leProxCaractere();
            q25();
        }
    }
    public void q30(){
        this.tokenReconhecido = Token.IF;
        if(proxCaractereIs(VARIAVEL)){
            leProxCaractere();
            q25();
        }
    }

    public void q31(){
        this.tokenReconhecido = Token.OPRELBIN;
        if(proxCaractereIs(VARIAVEL)){
            leProxCaractere();
            q25();
        }
    }
    public void q32(){
        this.tokenReconhecido = Token.VARIAVEL;
        if(this.proxCaractere == 'o'){
            leProxCaractere();
            q33();
        }else if(proxCaractereIs(VARIAVEL) && this.proxCaractere != 'o'){
            leProxCaractere();
            q25();
        }
    }
    public void q33(){
        this.tokenReconhecido = Token.VARIAVEL;
        if(this.proxCaractere =='t'){
            leProxCaractere();
            q34();
        }else if(proxCaractereIs(VARIAVEL) && this.proxCaractere != 't'){
            leProxCaractere();
            q25();
        }
    }
    public void q34(){
        this.tokenReconhecido = Token.OPLOGUN;
        if(proxCaractereIs(VARIAVEL)){
            leProxCaractere();
            q25();
        }
    } 
    
     public void q35(){
        this.tokenReconhecido = Token.PP;       
       
    } 

    public void fim()
    {
        this.tokenReconhecido = Token.EOF;
    }
    public int getLinha() {
        return linha;
    }
   
    
}
