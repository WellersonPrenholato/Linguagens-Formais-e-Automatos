package analisador_sint;
import analisador_lex.*;

public class a_sintatico extends Analisador implements tokens_comands 
{
	protected estados scanner;
	private int linha = 1;
        /**
         *  Instancia um analisador sintatico q
         * @author 
         * @param  _nomeArquivoEntrada : diretorio+nome do arquivo a ser analisado
         */

	public a_sintatico(String _nomeArquivoEntrada) {
		this.scanner = new estados(_nomeArquivoEntrada);
		// lê o primeiro token e o coloca no campo tokenReconhecido
		this.leProxToken();
	}
	
       

        public a_sintatico() {
		super();
	}


	public void leProxToken() 
        {
            this.scanner.q0();
            ignoreEspaco();
	}

        
       
        public void ignoreEspaco()
        {
            
            while ( this.scanner.tokenReconhecido == Token.ESPACO || this.scanner.tokenReconhecido == Token.SEPARADOR )
            { 
                this.scanner.q0();
            }
            
        }
        
       

	public void reconhece(Token t) {
            
            ignoreEspaco();
            if(t == this.scanner.tokenReconhecido ) 
            {
                this.leProxToken();
                System.out.println(this.scanner.tokenReconhecido + " Reconhecido");

            }
            else 
                throw new erros_sint(this.scanner.tokenReconhecido, this.scanner.getLinha());
	}

	
	public boolean proxTokenIs(Token t) {
		return t == this.scanner.tokenReconhecido;
	
                
}
}

