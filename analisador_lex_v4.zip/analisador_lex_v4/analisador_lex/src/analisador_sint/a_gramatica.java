package analisador_sint;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *  Classe que representa a Gramatica Livre de Contexto da linguagem.
 *  Verifica se a sintaxe esta correta 
 * @author 
 */

public class a_gramatica extends a_sintatico 
{
        /**
         * 
         * @param _nomeArquivoEntrada  nome do arquivo a ser testado
         */

	public a_gramatica(String _nomeArquivoEntrada) 
        {
		super(_nomeArquivoEntrada);
	}
	
       
        public void programa() 
        {
		listaComandos();
               
	}
        
        
         public void listaComandos() 
        {
            if( proxTokenIs(Token.IF) || 
                    proxTokenIs(Token.WHILE) ||
                    proxTokenIs(Token.FOR) ||
                    proxTokenIs(Token.PP) ||
                    proxTokenIs(Token.AP) || 
                    proxTokenIs(Token.NUM) ||
                    proxTokenIs(Token.VARIAVEL)|| 
                    proxTokenIs(Token.OPLOG)
                    ||proxTokenIs(Token.EOF)
                    ||proxTokenIs(Token.NEWLINE)
                    ||proxTokenIs(Token.PP)
                    
                    ){
                
              comando();
             listaComandos();
            }
                 if(proxTokenIs(Token.EOF)){
                 reconhece(Token.EOF);

            }
	}
        public void comando() {
            if(proxTokenIs(Token.IF)){
                If();
            }else if(proxTokenIs(Token.WHILE)){
                While();
            }else if(proxTokenIs(Token.FOR)){
                For();
            }else if(proxTokenIs(Token.ATRIBUICAO)){
                reconhece(Token.ATRIBUICAO);
            }else if(proxTokenIs(Token.VARIAVEL)){
                reconhece(Token.VARIAVEL);
                
            }
            else if(proxTokenIs(Token.OPLOGUN) || proxTokenIs(Token.AP) || proxTokenIs(Token.NUM) || proxTokenIs(Token.VARIAVEL) || proxTokenIs(Token.VARIAVEL)){
                //System.out.println("asdasddas");
                reconhece(Token.PP);
                
                expressao();
                
            }
            
          
            
	}
        public void For(){
          reconhece(Token.FOR);
          reconhece(Token.AP);
          condicional();
          reconhece(Token.FP);
        }
        public void If(){
          reconhece(Token.IF);
          reconhece(Token.AP);
          condicional();
          reconhece(Token.FP);
          
        }
        public void While(){
          reconhece(Token.WHILE);
          reconhece(Token.AP);
          condicional();
          reconhece(Token.FP);
        }
        public void condicional(){
            expressao();
           finalizador();
        }
        public void expressao(){
         
          if(proxTokenIs(Token.VARIAVEL)){
              
              reconhece(Token.VARIAVEL);
              expop();
          }else if(proxTokenIs(Token.OPRELBIN)){
              reconhece(Token.OPRELBIN);
               if(proxTokenIs(Token.NUM)){
                   reconhece(Token.NUM);
                   expop();
          }}
          else if(proxTokenIs(Token.NUM)){
              reconhece(Token.NUM);
               if(proxTokenIs(Token.OPRELBIN)){
                   reconhece(Token.OPRELBIN);
                   expop();
          }}
           else if(proxTokenIs(Token.OPUNBIN)){
              reconhece(Token.OPUNBIN);
               if(proxTokenIs(Token.NUM)){
                   reconhece(Token.NUM);
                   expressao();
          }
          
           
           }else if(proxTokenIs(Token.OPLOGUN)){
                reconhece(Token.OPLOGUN);
                expressao();
                expop();
          }
           
            
        }
          
                  
        
        public void expop(){
            operador();
            expressao();
            //expop();
        }
        public void operador(){
            if(proxTokenIs(Token.OPARITBIN)){
                reconhece(Token.OPARITBIN);
                expressao();
                
          }else if(proxTokenIs(Token.OPRELBIN)){
                reconhece(Token.OPRELBIN);
                expressao();
                
          }if(proxTokenIs(Token.OPLOGBIN)){
                reconhece(Token.OPLOGBIN);
                expressao();
          }
          if(proxTokenIs(Token.OPUNBIN)){
                reconhece(Token.OPUNBIN);
                expressao();
          }
        }
        public void finalizador(){
            //System.out.println("asdasddas");
            if(proxTokenIs(Token.PP)) {
                //System.out.println("asdasddas");
                 reconhece(Token.PP);
                 if(proxTokenIs(Token.NEWLINE)){
                 reconhece(Token.NEWLINE);
                 
                }
                 
            }
           
            
            else if(proxTokenIs(Token.EOF)){
                
            }

         }  
            
        public void atribuicao(){
          if(proxTokenIs(Token.VARIAVEL)) {
                 reconhece(Token.VARIAVEL);
                 expressao();
                 
          }
            
            else if(proxTokenIs(Token.ATRIBUICAO)){
                 reconhece(Token.ATRIBUICAO);
                 expressao();
            }
        }
        }
        

